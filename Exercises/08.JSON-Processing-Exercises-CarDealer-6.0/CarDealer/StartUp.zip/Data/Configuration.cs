﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server= .\SQLEXPRESS;Database=CarDealer;Integrated Security=true;TrustServerCertificate=True";
    }
}
