﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Data.Models
{
    public static class Constants
    {
        public  const int ColorNameMax = 100;
        public const int PositionNameMax = 50;
        public const int TeamLengthMax = 256;
        public const int InitialsLengthMax = 3;
    }
}
