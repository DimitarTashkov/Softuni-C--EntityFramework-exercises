﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server= .\SQLEXPRESS;Database=Medicines;Integrated Security=true;TrustServerCertificate=True";
    }
}
